 <div class="card">
 	<div class="card-header">
 		<h4>Hai <?=$this->session->userdata('nama_user')?> :)</h4>
 	</div>
 	<div class="card-body">
 		<p class="mb-2"><?= $quote?></p>
 	</div>
 </div>
 </div>
